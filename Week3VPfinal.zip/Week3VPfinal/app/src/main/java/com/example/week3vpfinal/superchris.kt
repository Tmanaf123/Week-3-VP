package com.example.week3vpfinal

import android.graphics.Bitmap

data class booking{

    val name: String
    val email: String
    val photo: Bitmap? = null
    
}