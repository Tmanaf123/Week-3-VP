package com.example.week3vpfinal

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri

fun loadScaledBitmap(context: Context, uri: Uri, maxSize: Int = 512): Bitmap? {
    return try {
        val resolver = context.contentResolver
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }

        var sample = 1
        while (bounds.outWidth / sample > maxSize || bounds.outHeight / sample > maxSize) {
            sample *= 2
        }

        val options = BitmapFactory.Options().apply { inSampleSize = sample }
        resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, options) }
    } catch (e: Exception) {
        null
        //hwo to how the how the when the when the when the when the when the when the when the when
        //same same same same same same same same same same same same asme msa zxzxzxzxz
        // even 31 it only took me like 6 mins to memorize all i think my limit for now 40 is push 45 doable
    }
}