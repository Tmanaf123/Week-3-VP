import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color

class Icons(
    imageVector: Any,
    contentDescription: String,
    tint: Color,
    modifier: Modifier
) {
    class Filled(imageVector: Any, contentDescription: String, tint: Color, modifier: Modifier) {

    }

}
