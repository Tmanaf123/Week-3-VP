import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color

class Filled(
    imageVector: Any,
    contentDescription: String,
    tint: androidx.compose.ui.graphics.Color,
    modifier: androidx.compose.ui.Modifier
) {

}
